#ifndef METAL_H
#define METAL_H

#define export __attribute__((used)) __attribute__ ((visibility ("default")))

#endif
