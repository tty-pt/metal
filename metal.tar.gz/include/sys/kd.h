#ifndef _SYS_KD_H
#define _SYS_KD_H

#define _LINUX_TYPES_H
#include <linux/kd.h>
#undef _LINUX_TYPES_H

#endif
